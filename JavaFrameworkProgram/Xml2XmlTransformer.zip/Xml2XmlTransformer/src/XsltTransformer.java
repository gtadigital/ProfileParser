import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;

public class XsltTransformer {
    public static void main(String[] args) throws IOException, URISyntaxException, TransformerException {
            String xmlFile = "groups.xml";
            String xslFile = "transformGroups.xsl";
            TransformerFactory factory = TransformerFactory.newInstance();
            Source xslt = new StreamSource(new File(xslFile));
            Transformer transformer = factory.newTransformer(xslt);
            Source text = new StreamSource(new File(xmlFile));
            transformer.transform(text, new StreamResult(new File("newGroups.xml")));
    }
}
	

